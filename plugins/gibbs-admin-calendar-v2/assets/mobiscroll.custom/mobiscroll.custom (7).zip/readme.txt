This is a commercial Mobiscroll package, licensed to Kamil  Gryga <kamil@gibbs.no> with license key c78fd514-6d09-4f48-ab45-10c0e453c91d.

In case of perpetual licenses please refer to the EULA licensing terms (present in the license folder) or https://mobiscroll.com/EULA for more info.

In case of SaaS licenses please refer to the license agreement you agreed to.