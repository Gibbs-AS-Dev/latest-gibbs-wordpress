import { Switch as SwitchComp } from '../../core/components/switch/switch.common';
export declare class Switch extends SwitchComp {
    static _fname: string;
    static _selector: string;
    static _renderOpt: import("../../preact/renderer").IRenderOptions;
}
export * from '../../core/components/switch/switch.types.public';
