import { Radio as RadioComp } from '../../core/components/radio/radio.common';
export declare class Radio extends RadioComp {
    static _fname: string;
    static _selector: string;
    static _renderOpt: import("../../preact/renderer").IRenderOptions;
}
export * from '../../core/components/radio/radio.types.public';
