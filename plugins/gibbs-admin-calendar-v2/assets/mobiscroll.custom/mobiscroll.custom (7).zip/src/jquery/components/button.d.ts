import { Button as ButtonComp } from '../../core/components/button/button.common';
export declare class Button extends ButtonComp {
    static _fname: string;
    static _selector: string;
    static _renderOpt: import("../../preact/renderer").IRenderOptions;
}
export * from '../../core/components/button/button.types.public';
