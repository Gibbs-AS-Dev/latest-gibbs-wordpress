import { Datepicker as DatepickerComp } from '../../core/components/datepicker/datepicker.common';
declare class Datepicker extends DatepickerComp {
    static _fname: string;
    static _renderOpt: import("../../preact/renderer").IRenderOptions;
}
export * from '../../core/components/datepicker/datepicker.public';
export { Datepicker };
