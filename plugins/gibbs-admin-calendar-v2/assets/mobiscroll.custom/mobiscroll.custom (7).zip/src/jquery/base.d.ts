export declare function registerComponent(Component?: any): void;
