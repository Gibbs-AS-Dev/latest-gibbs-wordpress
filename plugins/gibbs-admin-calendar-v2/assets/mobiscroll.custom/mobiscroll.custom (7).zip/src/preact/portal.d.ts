import { Component } from './lib/src/index';
interface IPortalProps {
    context: any;
    children: any;
}
/** @hidden */
export declare class Portal extends Component<IPortalProps> {
    render(): any;
}
export {};
