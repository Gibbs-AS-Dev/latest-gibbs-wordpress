export function createPortal(vnode: any, container: any): any;
