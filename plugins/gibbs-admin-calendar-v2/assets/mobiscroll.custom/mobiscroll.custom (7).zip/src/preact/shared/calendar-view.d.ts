export { CalendarView } from '../../core/shared/calendar-view/calendar-view.common';
