export { WeekDay } from '../../core/components/eventcalendar/scheduler/week-day.common';
