export { TimeIndicator } from '../../core/components/eventcalendar/scheduler/time-indicator.common';
