export { ScheduleEvent } from '../../core/components/eventcalendar/scheduler/schedule-event.common';
