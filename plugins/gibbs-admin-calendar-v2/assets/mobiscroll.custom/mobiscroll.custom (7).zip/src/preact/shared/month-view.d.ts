export { MonthView } from '../../core/shared/calendar-view/month-view.common';
