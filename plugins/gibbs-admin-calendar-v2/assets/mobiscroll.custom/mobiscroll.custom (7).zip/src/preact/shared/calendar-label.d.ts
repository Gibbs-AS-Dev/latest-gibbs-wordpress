export { CalendarLabel } from '../../core/shared/calendar-view/calendar-label.common';
