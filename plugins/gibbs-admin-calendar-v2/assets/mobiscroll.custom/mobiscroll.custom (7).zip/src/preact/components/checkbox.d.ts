import { IRenderOptions } from '../renderer';
export declare const renderOptions: IRenderOptions;
