export { Scheduler } from '../../core/components/eventcalendar/scheduler/scheduler.common';
