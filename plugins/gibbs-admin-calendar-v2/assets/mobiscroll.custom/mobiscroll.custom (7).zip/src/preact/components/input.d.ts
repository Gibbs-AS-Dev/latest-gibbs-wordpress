import { IRenderOptions } from '../renderer';
export { Input } from '../../core/components/input/input.common';
export declare const inputRenderOptions: IRenderOptions;
export declare const selectRenderOptions: IRenderOptions;
export declare const textareaRenderOptions: IRenderOptions;
