export { Icon } from '../../core/components/icon/icon.common';
