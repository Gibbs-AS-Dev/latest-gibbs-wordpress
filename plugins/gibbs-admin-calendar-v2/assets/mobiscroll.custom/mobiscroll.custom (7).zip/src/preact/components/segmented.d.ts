import { IRenderOptions } from '../renderer';
export { SegmentedGroup } from '../../core/components/segmented/segmented-group.common';
export { Segmented } from '../../core/components/segmented/segmented-item.common';
export declare const renderOptions: IRenderOptions;
export declare const groupRenderOptions: IRenderOptions;
