import { IRenderOptions } from '../renderer';
export { Popup } from '../../core/components/popup/popup.common';
export declare const renderOptions: IRenderOptions;
