import { IRenderOptions } from '../renderer';
export { Button } from '../../core/components/button/button.common';
export declare const renderOptions: IRenderOptions;
