export declare const remote: any;
