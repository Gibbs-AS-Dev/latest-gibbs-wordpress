import { IMonthViewProps, MonthViewBase } from './month-view';
export declare function template(s: IMonthViewProps, inst: MonthViewBase): any;
/** @hidden */
export declare class MonthView extends MonthViewBase {
    protected _template(s: IMonthViewProps): any;
}
