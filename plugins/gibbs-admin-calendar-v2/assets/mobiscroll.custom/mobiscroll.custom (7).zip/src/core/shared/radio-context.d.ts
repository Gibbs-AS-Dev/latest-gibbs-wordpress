export declare const RadioContext: import("../../preact/lib/src").Context<{}>;
