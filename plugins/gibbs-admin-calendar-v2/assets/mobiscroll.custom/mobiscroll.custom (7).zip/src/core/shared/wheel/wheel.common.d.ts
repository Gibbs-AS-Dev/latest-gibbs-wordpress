import { IWheelProps, WheelBase } from './wheel';
export declare function template(s: IWheelProps, inst: WheelBase): any;
export declare class Wheel extends WheelBase {
    protected _template(s: IWheelProps): any;
}
