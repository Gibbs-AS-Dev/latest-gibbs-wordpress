import { CalendarDayBase, ICalendarDayProps } from './calendar-day';
export declare function template(s: ICalendarDayProps, inst: CalendarDayBase): any;
export declare class CalendarDay extends CalendarDayBase {
    protected _template(s: ICalendarDayProps): any;
}
