import { CalendarLabelBase, ICalendarLabelProps } from './calendar-label';
export declare function template(s: ICalendarLabelProps, inst: CalendarLabelBase): any;
export declare class CalendarLabel extends CalendarLabelBase {
    protected _template(s: ICalendarLabelProps): any;
}
