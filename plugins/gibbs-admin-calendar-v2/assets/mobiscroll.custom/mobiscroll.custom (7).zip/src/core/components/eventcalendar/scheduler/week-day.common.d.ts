import { MbscWeekDayOptions, MbscWeekDayState, WeekDayBase } from './week-day';
export declare function template(s: MbscWeekDayOptions, state: MbscWeekDayState, inst: WeekDayBase): any;
export declare class WeekDay extends WeekDayBase {
    protected _template(s: MbscWeekDayOptions, state: MbscWeekDayState): any;
}
