import { Date } from './date.common';
export declare class Time extends Date {
    protected _preset: string;
}
