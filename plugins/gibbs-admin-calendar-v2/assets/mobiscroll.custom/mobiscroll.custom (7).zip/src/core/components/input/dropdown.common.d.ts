import { Input } from './input.common';
export declare class Dropdown extends Input {
    protected static _name: string;
    _tag: string;
}
