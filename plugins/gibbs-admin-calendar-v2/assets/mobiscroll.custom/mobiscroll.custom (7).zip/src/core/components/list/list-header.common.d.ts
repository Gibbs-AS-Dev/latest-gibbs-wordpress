import { ListHeaderBase, MbscListHeaderOptions } from './list-header';
export declare function template(s: MbscListHeaderOptions, inst: ListHeaderBase, content: any): any;
/**
 * The ListItem component
 */
export declare class ListHeader extends ListHeaderBase {
    protected _template(s: MbscListHeaderOptions): any;
}
