import { MbscCalendarSystem } from '../core/commons';
/** @hidden */
export declare const jalaliCalendar: MbscCalendarSystem;
