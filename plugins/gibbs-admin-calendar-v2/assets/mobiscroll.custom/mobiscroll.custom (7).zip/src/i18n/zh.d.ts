import { MbscLocale } from './locale';
declare const zh: MbscLocale;
export default zh;
