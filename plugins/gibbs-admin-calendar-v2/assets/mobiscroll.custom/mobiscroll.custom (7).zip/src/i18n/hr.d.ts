import { MbscLocale } from './locale';
declare const hr: MbscLocale;
export default hr;
