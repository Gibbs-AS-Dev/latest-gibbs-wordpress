import { MbscLocale } from './locale';
declare const hi: MbscLocale;
export default hi;
