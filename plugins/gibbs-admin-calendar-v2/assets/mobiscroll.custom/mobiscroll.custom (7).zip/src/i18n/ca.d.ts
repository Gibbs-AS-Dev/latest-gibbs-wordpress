import { MbscLocale } from './locale';
declare const ca: MbscLocale;
export default ca;
