import { MbscLocale } from './locale';
declare const ro: MbscLocale;
export default ro;
