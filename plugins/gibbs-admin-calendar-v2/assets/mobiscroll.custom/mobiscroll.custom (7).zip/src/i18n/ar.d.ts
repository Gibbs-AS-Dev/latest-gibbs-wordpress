import { MbscLocale } from './locale';
declare const ar: MbscLocale;
export default ar;
