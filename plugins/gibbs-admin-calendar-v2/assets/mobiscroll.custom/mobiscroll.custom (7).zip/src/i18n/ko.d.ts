import { MbscLocale } from './locale';
declare const ko: MbscLocale;
export default ko;
