import { MbscLocale } from './locale';
declare const th: MbscLocale;
export default th;
