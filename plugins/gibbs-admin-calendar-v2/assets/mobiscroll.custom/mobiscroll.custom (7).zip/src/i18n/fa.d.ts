import { MbscLocale } from './locale';
declare const fa: MbscLocale;
export default fa;
