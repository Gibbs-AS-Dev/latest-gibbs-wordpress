import { MbscLocale } from './locale';
declare const ruUA: MbscLocale;
export default ruUA;
