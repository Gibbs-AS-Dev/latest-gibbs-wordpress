import { MbscLocale } from './locale';
declare const sr: MbscLocale;
export default sr;
