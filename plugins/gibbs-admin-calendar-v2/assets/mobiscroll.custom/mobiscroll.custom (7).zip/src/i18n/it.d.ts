import { MbscLocale } from './locale';
declare const it: MbscLocale;
export default it;
