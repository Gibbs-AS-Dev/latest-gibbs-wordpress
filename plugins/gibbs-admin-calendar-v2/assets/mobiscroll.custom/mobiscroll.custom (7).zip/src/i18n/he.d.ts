import { MbscLocale } from './locale';
declare const he: MbscLocale;
export default he;
