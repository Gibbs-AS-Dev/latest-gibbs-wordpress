import { MbscLocale } from './locale';
declare const bg: MbscLocale;
export default bg;
