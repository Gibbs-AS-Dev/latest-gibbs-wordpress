import { MbscLocale } from './locale';
declare const sv: MbscLocale;
export default sv;
