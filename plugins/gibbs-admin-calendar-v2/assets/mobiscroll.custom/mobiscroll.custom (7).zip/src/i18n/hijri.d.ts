import { MbscCalendarSystem } from '../core/commons';
/** @hidden */
export declare const hijriCalendar: MbscCalendarSystem;
