import { MbscLocale } from './locale';
declare const ru: MbscLocale;
export default ru;
