import { MbscLocale } from './locale';
declare const ptBR: MbscLocale;
export default ptBR;
