import { MbscLocale } from './locale';
declare const fr: MbscLocale;
export default fr;
