import { MbscLocale } from './locale';
declare const da: MbscLocale;
export default da;
