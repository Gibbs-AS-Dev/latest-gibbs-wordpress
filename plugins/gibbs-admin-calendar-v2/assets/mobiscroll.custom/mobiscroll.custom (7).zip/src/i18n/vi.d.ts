import { MbscLocale } from './locale';
declare const vi: MbscLocale;
export default vi;
