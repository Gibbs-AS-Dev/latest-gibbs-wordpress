import { MbscLocale } from './locale';
declare const de: MbscLocale;
export default de;
