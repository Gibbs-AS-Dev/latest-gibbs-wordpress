import { MbscLocale } from './locale';
declare const el: MbscLocale;
export default el;
