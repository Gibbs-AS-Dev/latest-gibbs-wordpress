import { MbscLocale } from './locale';
declare const ptPT: MbscLocale;
export default ptPT;
