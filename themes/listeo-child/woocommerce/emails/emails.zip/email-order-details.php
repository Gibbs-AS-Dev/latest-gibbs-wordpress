<?php
/**
 * Order details table shown in emails.
 *
 * This template can be overridden by copying it to yourtheme/woocommerce/emails/email-order-details.php.
 *
 * HOWEVER, on occasion WooCommerce will need to update template files and you
 * (the theme developer) will need to copy the new files to your theme to
 * maintain compatibility. We try to do this as little as possible, but it does
 * happen. When this occurs the version of the template file will be bumped and
 * the readme will list any important changes.
 *
 * @see https://docs.woocommerce.com/document/template-structure/
 * @package WooCommerce\Templates\Emails
 * @version 3.7.0
 */

defined( 'ABSPATH' ) || exit;

$text_align = is_rtl() ? 'right' : 'left';

do_action( 'woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>

<h2>
	<?php
	if ( $sent_to_admin ) {
		$before = '<a class="link" href="' . esc_url( $order->get_edit_order_url() ) . '">';
		$after  = '</a>';
	} else {
		$before = '';
		$after  = '';
	}
	/* translators: %s: Order ID. */
	echo wp_kses_post( $before . sprintf( __( '[Kvittering for ordre #%s]', 'woocommerce' ) . $after . ' (<time datetime="%s">%s</time>)', $order->get_order_number(), $order->get_date_created()->format( 'c' ), wc_format_datetime( $order->get_date_created() ) ) );
	?>
</h2>
<?php 
 global $wpdb;
 $result  = $wpdb -> get_results( "SELECT * FROM `" . $wpdb->prefix . "bookings_calendar` WHERE order_id=".$order->get_order_number());
//print_r($result);
//echo $result[0]->date_start;

 $details_comment = json_decode($result[0]->comment);
	//// echo '<pre>';
//print_r( $details_comment);
// echo '</pre>';
 
 
	 $listeo_services=get_post_meta($result[0]->listing_id,'_menu',true);
 //echo '<pre>';
//print_r( $listeo_services[0]['menu_elements'][0]['tax']);
 //echo '</pre>';
 
 
 $booking_for_date=date(get_option( 'date_format' ), strtotime($result[0]->date_start)).' '.date(get_option( 'time_format' ), strtotime($result[0]->date_start)) .' - '. date(get_option( 'date_format' ), strtotime($result[0]->date_end)).' '.date(get_option( 'time_format' ), strtotime($result[0]->date_end));	?>
		<p>Dato: <?php echo wp_kses_post( $booking_for_date); ?></p>
					
<div style="margin-bottom: 40px;">
	<table class="td" cellspacing="0" cellpadding="6" style="width: 100%; font-family: 'Helvetica Neue', Helvetica, Roboto, Arial, sans-serif;" border="1">
		<thead>
			<tr>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Product', 'woocommerce' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Antall/gjester', 'woocommerce' ); ?></th>
				<th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Price', 'woocommerce' ); ?></th>
                <th class="td" scope="col" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Mva', 'woocommerce' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<?php
			$product_tax_prcentage=get_post_meta($result[0]->listing_id,'_tax',true);
			echo wc_get_email_order_items( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$order,
				array(
					'show_sku'      => $sent_to_admin,
					'show_image'    => false,
					'image_size'    => array( 32, 32 ),
					'plain_text'    => $plain_text,
					'sent_to_admin' => $sent_to_admin,
				)
			);
			?>
		</tbody>
		<tfoot>
			<?php
			$item_totals = $order->get_order_item_totals();

			if ( $item_totals ) {
			$p = 0;	
						if($result){ 
						
	// $listeo_services[0]['menu_elements'][$p]['tax'];				
	 $details_comment = json_decode($result[0]->comment); 
	 $discount_type=get_post_meta($result[0]->ID,'discount-type',true);
     $discount_percentage = get_post_meta($result[0]->listing_id,$discount_type,true);
        if(is_numeric($discount_percentage)){
			$percentInDecimal = intval($discount_percentage) / 100;
            $normal_price = $result[0]->price - ($result[0]->price * $percentInDecimal);
			$product_tax_price=$normal_price *($product_tax_prcentage/100);?>
			
			 <tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Målgruppe rabatt</th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( $discount_percentage).'%'; ?></td>
                         <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"></td>
					</tr>
                    
                    <tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Pris etter rabatt</th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $normal_price)); ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $product_tax_price)); ?></td>
					</tr>	
			     <?php    }else{
			  $percentInDecimal = intval(0) / 100;
			 $normal_price = $result[0]->price - ($result[0]->price * $percentInDecimal);
			 $product_tax_price=$normal_price *($product_tax_prcentage/100);
			}
		
		
          	?>
    
   
                    
                     
                    
                    <tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Delsum</th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $normal_price)); ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $product_tax_price)); ?></td>
                        
					</tr>
	
		
 <?php 
 $total_addtional_price=0;
 $total_addtional_tax=0;
 if($details_comment->service){
 foreach($details_comment->service as $service_price){
	 $countable=$service_price->countable;
	 $quatity_price=$countable * $service_price->service->price;
	// $normal_price= $normal_price + $service_price->service->price;
	 $total_addtional_price= $total_addtional_price + $quatity_price;
	 $addtional_servic_tax=$listeo_services[0]['menu_elements'][$p]['tax'];	
	 $tax_deducted_price=$quatity_price *($addtional_servic_tax/100);
	 $total_addtional_tax =$total_addtional_tax + $tax_deducted_price;
	 $p++;
				if( $p===1){?>
                <tr>
						<th class="td" scope="row" colspan="4" style="text-align:<?php echo esc_attr( $text_align ); ?>; border-top-width: 4px;">Ekstra tjenester</th>
                        </tr>
				<tr>
                <?php }?>
                		<th class="td" scope="row" colspan="" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( $service_price->service->name ); ?></th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo $countable; ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $quatity_price)); ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $tax_deducted_price )); ?></td>
					</tr>	
					
				<?php 	} 
				
				$sum_product_services=$normal_price + $total_addtional_price;
				$sum_product_services_tax=$product_tax_price + $total_addtional_tax;
				$total_amount=$sum_product_services + $sum_product_services_tax;
				?>
				
				<tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Delsum</th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $total_addtional_price )); ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $total_addtional_tax )); ?></td>
                        
					</tr>
				
			<?php 	}else{
				
				$sum_product_services=$normal_price;
				$sum_product_services_tax=$product_tax_price;
				$total_amount=$sum_product_services + $sum_product_services_tax;
				
				}}
				
				
				
				if($result){
					
					
					$i = 0;	
				foreach ( $item_totals as $total ) {
					$i++;
					
					 /*?> if($total['label']== 'Delsum:' || $total['label']== 'Totalt:'){ }else{
					?>
					<tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php  echo wp_kses_post( $total['label'] ); ?></th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i  ) ? 'border-top-width: 4px;' : ''; ?>"><?php echo wp_kses_post( $total['value'] );?></td>
					</tr>
					<?php
				} <?php */?>
				
				<?php }
					
					
					
					?>   
					
					<tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;border-top-width: 4px;">Sum</th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; border-top-width: 4px;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $sum_product_services )); ?></td>
                        <td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; border-top-width: 4px;"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $sum_product_services_tax )); ?></td>
                        
					</tr>
                    
                    <tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;">Total ink mva</th>
						<td class="td" style="text-align:right;" colspan="2"><?php echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $total_amount )); ?></td>
                       
                        
					</tr>
                    
					
					<?php  }else{
				
				$i = 0;	
				foreach ( $item_totals as $total ) {
					$i++;
					
					
					?>
					<tr>
						<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i ) ? 'border-top-width: 4px;' : ''; ?>"><?php  echo wp_kses_post( $total['label'] ); ?></th>
						<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>; <?php echo ( 1 === $i  ) ? 'border-top-width: 4px;' : ''; ?>"><?php if($result){ if($total['label']== 'Delsum:' || $total['label']== 'Totalt:') {echo get_woocommerce_currency_symbol().' '; echo sprintf('%.2f',wp_kses_post( $normal_price )); }else {echo wp_kses_post( $total['value'] );}}else {echo wp_kses_post( $total['value'] );} ?></td>
					</tr>
					<?php
				} }
					
			}
			if ( $order->get_customer_note() ) {
				?>
				<tr>
					<th class="td" scope="row" colspan="2" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php esc_html_e( 'Note:', 'woocommerce' ); ?></th>
					<td class="td" style="text-align:<?php echo esc_attr( $text_align ); ?>;"><?php echo wp_kses_post( nl2br( wptexturize( $order->get_customer_note() ) ) ); ?></td>
				</tr>
				<?php
			}
			?>
		</tfoot>
	</table>
</div>

<?php do_action( 'woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text, $email ); ?>
